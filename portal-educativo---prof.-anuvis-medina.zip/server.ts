import express from "express";
import path from "path";
import fs from "fs";
import multer from "multer";
import { createServer as createViteServer } from "vite";

interface Submission {
  id: string;
  name: string;
  ci: string;
  section: "Primer Grado" | "Segundo Grado" | "Tercer Grado" | "Cuarto Grado" | "Quinto Grado";
  driveLink: string;
  reviewed: boolean;
  createdAt: string;
  comments?: string;
  grade?: string;
  feedback?: string;
  gradedAt?: string;
  updatedAt?: string;
  assignmentId?: string;
  assignmentTitle?: string;
  attachmentName?: string;
  feedbackAttachmentUrl?: string;
  feedbackAttachmentName?: string;
}

interface AuthorizedStudent {
  id: string;
  name: string;
  ci: string;
  section: "Primer Grado" | "Segundo Grado" | "Tercer Grado" | "Cuarto Grado" | "Quinto Grado";
  createdAt: string;
}

interface Assignment {
  id: string;
  title: string;
  description: string;
  section: "Primer Grado" | "Segundo Grado" | "Tercer Grado" | "Cuarto Grado" | "Quinto Grado" | "TODOS";
  createdAt: string;
  dueDate?: string;
  attachmentLink?: string;
  attachmentName?: string;
}

interface ChatRoom {
  id: string;
  type: "GRADE" | "ASSIGNMENT" | "PRIVATE" | "GROUP";
  name: string;
  section?: "Primer Grado" | "Segundo Grado" | "Tercer Grado" | "Cuarto Grado" | "Quinto Grado";
  assignmentId?: string;
  memberCis?: string[];
  createdAt: string;
}

interface ChatMessage {
  id: string;
  roomId: string;
  senderName: string;
  senderCi?: string;
  senderRole: "STUDENT" | "TEACHER";
  message: string;
  createdAt: string;
  mediaUrl?: string;
  mediaType?: "sticker" | "video" | "document" | "image";
  mediaName?: string;
}

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    const sanitizedBase = path.basename(file.originalname, ext)
      .replace(/[^a-zA-Z0-9]/g, "_");
    cb(null, `${sanitizedBase}-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB max file size to support heavy PDFs, images, docs easily
  }
});

function migrateSection(sec: any): "Primer Grado" | "Segundo Grado" | "Tercer Grado" | "Cuarto Grado" | "Quinto Grado" {
  if (sec === "A" || sec === "Primer Grado") return "Primer Grado";
  if (sec === "B" || sec === "Segundo Grado") return "Segundo Grado";
  if (sec === "C" || sec === "Tercer Grado") return "Tercer Grado";
  if (sec === "D" || sec === "Cuarto Grado") return "Cuarto Grado";
  if (sec === "E" || sec === "Quinto Grado") return "Quinto Grado";
  return "Primer Grado"; // Fallback
}

interface AppNotification {
  id: string;
  recipientRole: "TEACHER" | "STUDENT";
  recipientCi?: string;
  title: string;
  message: string;
  type: "SUBMISSION" | "GRADE" | "SYSTEM";
  read: boolean;
  createdAt: string;
  archived?: boolean;
}

const PORT = 3000;
const DATA_FILE_PATH = path.join(process.cwd(), "submissions.json");
const ALLOWED_STUDENTS_FILE_PATH = path.join(process.cwd(), "allowed_students.json");
const NOTIFICATIONS_FILE_PATH = path.join(process.cwd(), "notifications.json");
const ASSIGNMENTS_FILE_PATH = path.join(process.cwd(), "assignments.json");
const CHAT_ROOMS_FILE_PATH = path.join(process.cwd(), "chat_rooms.json");
const CHAT_MESSAGES_FILE_PATH = path.join(process.cwd(), "chat_messages.json");

// In-memory falls
let submissionsList: Submission[] = [];
let allowedStudentsList: AuthorizedStudent[] = [];
let notificationsList: AppNotification[] = [];
let assignmentsList: Assignment[] = [];
let chatRoomsList: ChatRoom[] = [];
let chatMessagesList: ChatMessage[] = [];

// Load existing notifications
try {
  if (fs.existsSync(NOTIFICATIONS_FILE_PATH)) {
    const notificationsContent = fs.readFileSync(NOTIFICATIONS_FILE_PATH, "utf-8");
    notificationsList = JSON.parse(notificationsContent);
    console.log(`Loaded ${notificationsList.length} notifications from JSON file.`);
  } else {
    const initialNotifications: AppNotification[] = [
      {
        id: "sys-1",
        recipientRole: "TEACHER",
        title: "Bienvenida Profesora",
        message: "Bienvenida al panel administrativo. Aquí podrá revisar todas las tareas entregadas por los alumnos y asignar calificaciones.",
        type: "SYSTEM",
        read: false,
        createdAt: new Date().toISOString()
      },
      {
        id: "sys-2",
        recipientRole: "STUDENT",
        title: "Portal Escolar Activo",
        message: "¡La plataforma está lista para recibir tus tareas! Ingresa tu número de cédula en la sección correspondiente.",
        type: "SYSTEM",
        read: false,
        createdAt: new Date().toISOString()
      }
    ];
    notificationsList = initialNotifications;
    fs.writeFileSync(NOTIFICATIONS_FILE_PATH, JSON.stringify(initialNotifications, null, 2), "utf-8");
    console.log("Created initial empty notifications.json file.");
  }
} catch (err) {
  console.warn("Could not load notifications file, using in-memory state:", err);
}

// Load existing submissions if they exist
try {
  if (fs.existsSync(DATA_FILE_PATH)) {
    const fileContent = fs.readFileSync(DATA_FILE_PATH, "utf-8");
    submissionsList = JSON.parse(fileContent);
    // Migrate old sections to new grade names
    let modified = false;
    submissionsList = submissionsList.map(sub => {
      const migrated = migrateSection(sub.section);
      if (migrated !== sub.section) {
        modified = true;
        return { ...sub, section: migrated };
      }
      return sub;
    });
    if (modified) {
      fs.writeFileSync(DATA_FILE_PATH, JSON.stringify(submissionsList, null, 2), "utf-8");
    }
    console.log(`Loaded ${submissionsList.length} submissions from JSON file.`);
  } else {
    // Bootstrap initial empty key
    fs.writeFileSync(DATA_FILE_PATH, JSON.stringify([], null, 2), "utf-8");
    console.log("Created initial empty submissions.json file.");
  }
} catch (err) {
  console.warn("Could not load submissions file, using in-memory state:", err);
}

// Load existing authorized students or bootstrap with default list
try {
  if (fs.existsSync(ALLOWED_STUDENTS_FILE_PATH)) {
    const studentsContent = fs.readFileSync(ALLOWED_STUDENTS_FILE_PATH, "utf-8");
    allowedStudentsList = JSON.parse(studentsContent);
    // Migrate old sections to new grade names
    let modified = false;
    allowedStudentsList = allowedStudentsList.map(st => {
      const migrated = migrateSection(st.section);
      if (migrated !== st.section) {
        modified = true;
        return { ...st, section: migrated };
      }
      return st;
    });
    if (modified) {
      fs.writeFileSync(ALLOWED_STUDENTS_FILE_PATH, JSON.stringify(allowedStudentsList, null, 2), "utf-8");
    }
    console.log(`Loaded ${allowedStudentsList.length} authorized students from JSON file.`);
  } else {
    // Bootstrap with demo students using new grades names
    const demoStudents: AuthorizedStudent[] = [
      { id: "demo-1", name: "CARLOS PÉREZ", ci: "12345678", section: "Primer Grado", createdAt: new Date().toISOString() },
      { id: "demo-2", name: "MARÍA GÓMEZ", ci: "87654321", section: "Segundo Grado", createdAt: new Date().toISOString() },
      { id: "demo-3", name: "JOSÉ RODRÍGUEZ", ci: "11223344", section: "Tercer Grado", createdAt: new Date().toISOString() },
      { id: "demo-4", name: "ANA MARTÍNEZ", ci: "44332211", section: "Cuarto Grado", createdAt: new Date().toISOString() },
      { id: "demo-5", name: "ESTUDIANTE DEMO", ci: "12345", section: "Primer Grado", createdAt: new Date().toISOString() }
    ];
    allowedStudentsList = demoStudents;
    fs.writeFileSync(ALLOWED_STUDENTS_FILE_PATH, JSON.stringify(demoStudents, null, 2), "utf-8");
    console.log("Created initial allowed_students.json file with demo accounts.");
  }
} catch (err) {
  console.warn("Could not load authorized students file, using in-memory state:", err);
}

// Load assignments
try {
  if (fs.existsSync(ASSIGNMENTS_FILE_PATH)) {
    const assignmentsContent = fs.readFileSync(ASSIGNMENTS_FILE_PATH, "utf-8");
    assignmentsList = JSON.parse(assignmentsContent);
    console.log(`Loaded ${assignmentsList.length} assignments from JSON file.`);
  } else {
    const initialAssignments: Assignment[] = [
      {
        id: "asg-1",
        title: "Ecuaciones de Segundo Grado",
        description: "Resolver los ejercicios de la página 45 a la 47 del libro de texto y subir el enlace de Google Drive con las fotos de la resolución.",
        section: "Tercer Grado",
        createdAt: new Date().toISOString(),
        dueDate: "Entregar antes del viernes",
      },
      {
        id: "asg-2",
        title: "Lectura Comprensiva de Cuentos",
        description: "Leer el cuento 'El almohadón de plumas' de Horacio Quiroga y realizar un resumen crítico de una página.",
        section: "Primer Grado",
        createdAt: new Date().toISOString(),
        dueDate: "Próximo miércoles",
      }
    ];
    assignmentsList = initialAssignments;
    fs.writeFileSync(ASSIGNMENTS_FILE_PATH, JSON.stringify(initialAssignments, null, 2), "utf-8");
    console.log("Created initial assignments.json file.");
  }
} catch (err) {
  console.warn("Could not load assignments file, using in-memory state:", err);
}

// Load chat rooms
try {
  if (fs.existsSync(CHAT_ROOMS_FILE_PATH)) {
    const chatRoomsContent = fs.readFileSync(CHAT_ROOMS_FILE_PATH, "utf-8");
    chatRoomsList = JSON.parse(chatRoomsContent);
    console.log(`Loaded ${chatRoomsList.length} chat rooms from JSON.`);
  } else {
    // Bootstrap standard Grade rooms
    const defaultRooms: ChatRoom[] = [
      { id: "grade-Primer Grado", type: "GRADE", name: "Salón de Primer Grado", section: "Primer Grado", createdAt: new Date().toISOString() },
      { id: "grade-Segundo Grado", type: "GRADE", name: "Salón de Segundo Grado", section: "Segundo Grado", createdAt: new Date().toISOString() },
      { id: "grade-Tercer Grado", type: "GRADE", name: "Salón de Tercer Grado", section: "Tercer Grado", createdAt: new Date().toISOString() },
      { id: "grade-Cuarto Grado", type: "GRADE", name: "Salón de Cuarto Grado", section: "Cuarto Grado", createdAt: new Date().toISOString() },
      { id: "grade-Quinto Grado", type: "GRADE", name: "Salón de Quinto Grado", section: "Quinto Grado", createdAt: new Date().toISOString() },
    ];
    chatRoomsList = defaultRooms;
    fs.writeFileSync(CHAT_ROOMS_FILE_PATH, JSON.stringify(defaultRooms, null, 2), "utf-8");
    console.log("Initialized default grade chat rooms.");
  }
} catch (err) {
  console.warn("Could not load chat rooms file:", err);
}

// Load chat messages
try {
  if (fs.existsSync(CHAT_MESSAGES_FILE_PATH)) {
    const chatMessagesContent = fs.readFileSync(CHAT_MESSAGES_FILE_PATH, "utf-8");
    chatMessagesList = JSON.parse(chatMessagesContent);
    console.log(`Loaded ${chatMessagesList.length} chat messages from JSON.`);
  } else {
    // Bootstrap welcomes
    const defaultMessages: ChatMessage[] = [
      {
        id: "msg-init-1",
        roomId: "grade-Primer Grado",
        senderName: "SISTEMA",
        senderRole: "TEACHER",
        message: "¡Bienvenidos al chat oficial de Primer Grado! Aquí los alumnos pueden interactuar y hacer consultas a la profesora.",
        createdAt: new Date().toISOString()
      },
      {
        id: "msg-init-2",
        roomId: "grade-Segundo Grado",
        senderName: "SISTEMA",
        senderRole: "TEACHER",
        message: "¡Bienvenidos al chat oficial de Segundo Grado! Este espacio es para interactuar sanamente y aclarar dudas con la docente.",
        createdAt: new Date().toISOString()
      },
      {
        id: "msg-init-3",
        roomId: "grade-Tercer Grado",
        senderName: "SISTEMA",
        senderRole: "TEACHER",
        message: "¡Bienvenidos al chat oficial de Tercer Grado! Comenta tus inquietudes sobre las tareas escolares aquí.",
        createdAt: new Date().toISOString()
      }
    ];
    chatMessagesList = defaultMessages;
    fs.writeFileSync(CHAT_MESSAGES_FILE_PATH, JSON.stringify(defaultMessages, null, 2), "utf-8");
    console.log("Initialized default chat messages.");
  }
} catch (err) {
  console.warn("Could not load chat messages file:", err);
}

// Persist and load chat rooms/students restrictions
const CHAT_RESTRICTIONS_FILE_PATH = path.join(process.cwd(), "chat_restrictions.json");
let restrictedCisList: string[] = [];
let mutedRoomsList: string[] = [];

try {
  if (fs.existsSync(CHAT_RESTRICTIONS_FILE_PATH)) {
    const content = fs.readFileSync(CHAT_RESTRICTIONS_FILE_PATH, "utf-8");
    const parsed = JSON.parse(content);
    restrictedCisList = parsed.restrictedCis || [];
    mutedRoomsList = parsed.mutedRooms || [];
    console.log(`Loaded ${restrictedCisList.length} restricted students and ${mutedRoomsList.length} muted rooms.`);
  } else {
    fs.writeFileSync(CHAT_RESTRICTIONS_FILE_PATH, JSON.stringify({ restrictedCis: [], mutedRooms: [] }, null, 2), "utf-8");
  }
} catch (err) {
  console.warn("Could not load restrictions file, using in-memory state:", err);
}

function saveRestrictions() {
  try {
    fs.writeFileSync(CHAT_RESTRICTIONS_FILE_PATH, JSON.stringify({
      restrictedCis: restrictedCisList,
      mutedRooms: mutedRoomsList
    }, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving restrictions:", err);
  }
}

// Common offensive vocabulary filtering for student chats (Venezuela context and general Spanish)
const offensiveWords = [
  "mierda", "coño", "maldito", "maldita", "puta", "puto", "hijo de puta", "hija de puta",
  "pendejo", "pendeja", "marico", "marica", "guevon", "guevon", "huevon", "huevon",
  "verga", "culiado", "culiada", "estupido", "estupida", "estupida", "estupido",
  "mamaguevo", "mamagüevo", "coñazo", "carajo", "singar", "singado"
];

function hasOffensiveContent(text: string): boolean {
  if (!text) return false;
  const normalized = text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); // removes accents
  return offensiveWords.some(word => {
    const escapedWord = word.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const regex = new RegExp(`\\b${escapedWord}\\b`, 'i');
    return regex.test(normalized);
  });
}

// Save helpers
function saveChatRooms() {
  try {
    fs.writeFileSync(CHAT_ROOMS_FILE_PATH, JSON.stringify(chatRoomsList, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving chat rooms:", err);
  }
}

function saveChatMessages() {
  try {
    fs.writeFileSync(CHAT_MESSAGES_FILE_PATH, JSON.stringify(chatMessagesList, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving chat messages:", err);
  }
}

// Save helpers
function saveSubmissions() {
  try {
    fs.writeFileSync(DATA_FILE_PATH, JSON.stringify(submissionsList, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving submissions to file:", err);
  }
}

function saveAllowedStudents() {
  try {
    fs.writeFileSync(ALLOWED_STUDENTS_FILE_PATH, JSON.stringify(allowedStudentsList, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving authorized students to file:", err);
  }
}

function saveNotifications() {
  try {
    fs.writeFileSync(NOTIFICATIONS_FILE_PATH, JSON.stringify(notificationsList, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving notifications to file:", err);
  }
}

function saveAssignments() {
  try {
    fs.writeFileSync(ASSIGNMENTS_FILE_PATH, JSON.stringify(assignmentsList, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving assignments to file:", err);
  }
}

async function startServer() {
  const app = express();

  // Parse JSON bodies
  app.use(express.json());

  // API Routes
  app.get("/api/submissions", (req, res) => {
    res.json(submissionsList);
  });

  // Find my grade (for students)
  app.get("/api/submissions/my-grade", (req, res) => {
    const { ci } = req.query;
    if (!ci) {
      return res.status(400).json({ error: "Debe ingresar una cédula para consultar." });
    }

    const queryCi = String(ci).replace(/\D/g, "");
    if (!queryCi) {
      return res.status(400).json({ error: "Cédula inválida." });
    }

    const studentSubmissions = submissionsList.filter(
      (sub) => sub.ci.replace(/\D/g, "") === queryCi
    );

    res.json(studentSubmissions);
  });

  // POST submission with security validation
  app.post("/api/submissions", (req, res) => {
    const { name, ci, section, driveLink, comments, assignmentId, assignmentTitle, attachmentName } = req.body;

    // Basic server-side validation
    if (!name || !ci || !section || !driveLink) {
      return res.status(400).json({ error: "Todos los campos son obligatorios." });
    }

    if (!["Primer Grado", "Segundo Grado", "Tercer Grado", "Cuarto Grado", "Quinto Grado"].includes(section)) {
      return res.status(400).json({ error: "Grado seleccionado no es válido." });
    }

    // SECURITY VERIFICATION: check if student is in authorized list for this section
    const normCi = ci.toString().replace(/\D/g, "");
    const isAuthorized = allowedStudentsList.some(
      (s) => s.ci.replace(/\D/g, "") === normCi && s.section === section
    );

    if (!isAuthorized) {
      return res.status(403).json({
        error: `Acceso Denegado por Seguridad: El número de Cédula (${ci}) no está registrado/autorizado en el ${section} por la Profesora. Comunícate con ella para que te añada a la lista de alumnos.`
      });
    }

    // Verify format of driveLink (Google Drive link or any valid URL)
    let urlString = driveLink.trim();
    if (!urlString.startsWith("http://") && !urlString.startsWith("https://") && !urlString.startsWith("/api/files/")) {
      urlString = "https://" + urlString;
    }

    const newSubmission: Submission = {
      id: Math.random().toString(36).substring(2, 11),
      name: name.trim(),
      ci: ci.toString().trim(),
      section: section as "Primer Grado" | "Segundo Grado" | "Tercer Grado" | "Cuarto Grado" | "Quinto Grado",
      driveLink: urlString,
      reviewed: false,
      createdAt: new Date().toISOString(),
      comments: comments ? comments.trim() : undefined,
      assignmentId: assignmentId || undefined,
      assignmentTitle: assignmentTitle || undefined,
      attachmentName: attachmentName ? attachmentName.trim() : undefined,
    };

    submissionsList.unshift(newSubmission); // Newest first
    saveSubmissions();

    // Create notification for teacher
    const teacherNotification: AppNotification = {
      id: "notif-" + Math.random().toString(36).substring(2, 11),
      recipientRole: "TEACHER",
      title: "Nueva Tarea de Alumno",
      message: `${name.trim()} (${section}) ha enviado su tarea para evaluación.`,
      type: "SUBMISSION",
      read: false,
      createdAt: new Date().toISOString()
    };
    notificationsList.unshift(teacherNotification);
    saveNotifications();

    res.status(201).json({ success: true, submission: newSubmission });
  });

  // POST grade to sub
  app.post("/api/submissions/:id/grade", (req, res) => {
    const { id } = req.params;
    const { grade, feedback, feedbackAttachmentUrl, feedbackAttachmentName } = req.body;

    const submission = submissionsList.find((s) => s.id === id);
    if (!submission) {
      return res.status(404).json({ error: "Tarea no encontrada." });
    }

    // Capture if it is a modification (already had grade, feedback, or gradedAt)
    const isModification = !!(submission.grade !== undefined || submission.feedback !== undefined || submission.gradedAt);

    submission.grade = grade || undefined;
    submission.feedback = feedback || undefined;
    submission.feedbackAttachmentUrl = feedbackAttachmentUrl || undefined;
    submission.feedbackAttachmentName = feedbackAttachmentName || undefined;
    submission.reviewed = true; // Automatically marked as reviewed when graded
    
    const now = new Date().toISOString();
    if (!submission.gradedAt) {
      submission.gradedAt = now;
    }

    if (isModification) {
      submission.updatedAt = now;
    }

    saveSubmissions();

    // Create notification for student
    const studentNotification: AppNotification = {
      id: "notif-" + Math.random().toString(36).substring(2, 11),
      recipientRole: "STUDENT",
      recipientCi: submission.ci.replace(/\D/g, ""),
      title: isModification ? "Calificación Actualizada" : "Tarea Calificada 🎉",
      message: `La profesora ha ${isModification ? "actualizado la" : "calificado tu"} tarea en la Sección ${submission.section}. Nota: ${grade || "No Asignada"}`,
      type: "GRADE",
      read: false,
      createdAt: now
    };
    notificationsList.unshift(studentNotification);
    saveNotifications();

    res.json({ success: true, submission });
  });

  // GET notifications
  app.get("/api/notifications", (req, res) => {
    const { role, ci } = req.query;
    let filtered = notificationsList;
    if (role) {
      filtered = filtered.filter(n => n.recipientRole === role);
    }
    if (ci) {
      const matchCi = String(ci).replace(/\D/g, "");
      filtered = filtered.filter(n => !n.recipientCi || n.recipientCi === matchCi);
    }
    res.json(filtered);
  });

  // POST mark single notification as read
  app.post("/api/notifications/:id/read", (req, res) => {
    const { id } = req.params;
    const notification = notificationsList.find(n => n.id === id);
    if (!notification) {
      return res.status(404).json({ error: "Notificación no encontrada." });
    }
    notification.read = true;
    saveNotifications();
    res.json({ success: true, notification });
  });

  // POST mark all as read for role
  app.post("/api/notifications/read-all", (req, res) => {
    const { role, ci } = req.body;
    let count = 0;
    notificationsList.forEach(n => {
      const matchesRole = role ? n.recipientRole === role : true;
      const matchesCi = ci ? n.recipientCi === String(ci).replace(/\D/g, "") : true;
      if (matchesRole && matchesCi && !n.read) {
        n.read = true;
        count++;
      }
    });
    if (count > 0) {
      saveNotifications();
    }
    res.json({ success: true, count });
  });

  // POST clear notifications for role/student
  app.post("/api/notifications/clear", (req, res) => {
    const { role, ci } = req.body;
    
    if (role || ci) {
      notificationsList = notificationsList.filter(n => {
        const matchesRole = role ? n.recipientRole === role : true;
        const matchesCi = ci ? n.recipientCi === String(ci).replace(/\D/g, "") : true;
        return !(matchesRole && matchesCi);
      });
    } else {
      notificationsList = [];
    }
    
    saveNotifications();
    res.json({ success: true });
  });

  // GET assignments
  app.get("/api/assignments", (req, res) => {
    const { section, ci } = req.query;
    
    let targetSection = section ? String(section) : null;
    
    if (ci) {
      const normCi = String(ci).replace(/\D/g, "");
      const student = allowedStudentsList.find(s => s.ci.replace(/\D/g, "") === normCi);
      if (student) {
        targetSection = student.section;
      }
    }
    
    if (targetSection) {
      const filtered = assignmentsList.filter(
        item => item.section === targetSection || item.section === "TODOS"
      );
      return res.json(filtered);
    }
    
    res.json(assignmentsList);
  });

  // POST assignments (Teacher adds a new homework/task description)
  app.post("/api/assignments", (req, res) => {
    const { title, description, section, dueDate, attachmentLink, attachmentName } = req.body;
    if (!title || !description || !section) {
      return res.status(400).json({ error: "Título, descripción y grado son obligatorios." });
    }
    
    const VALID_SECTIONS_WITH_ALL = ["Primer Grado", "Segundo Grado", "Tercer Grado", "Cuarto Grado", "Quinto Grado", "TODOS"];
    if (!VALID_SECTIONS_WITH_ALL.includes(section)) {
      return res.status(400).json({ error: "Grado seleccionado no es válido." });
    }
    
    const newAssignment: Assignment = {
      id: Math.random().toString(36).substring(2, 11),
      title: title.trim(),
      description: description.trim(),
      section: section as any,
      createdAt: new Date().toISOString(),
      dueDate: dueDate ? dueDate.trim() : undefined,
      attachmentLink: attachmentLink ? attachmentLink.trim() : undefined,
      attachmentName: attachmentName ? attachmentName.trim() : undefined
    };
    
    assignmentsList.unshift(newAssignment);
    saveAssignments();
    
    // Auto-create a notification to the role: STUDENT
    const notifMsg = `Nueva tarea publicada para ${section}: "${title.trim()}"`;
    const newNotif: AppNotification = {
      id: "asg-notif-" + Math.random().toString(36).substring(2, 11),
      recipientRole: "STUDENT",
      title: "Nueva Tarea Asignada 📋",
      message: notifMsg,
      type: "SYSTEM",
      read: false,
      createdAt: new Date().toISOString()
    };
    notificationsList.unshift(newNotif);
    saveNotifications();
    
    res.status(201).json({ success: true, assignment: newAssignment });
  });

  // GET all chat rooms for a user/student/teacher
  app.get("/api/chat/rooms", (req, res) => {
    const { role, ci, section } = req.query;

    if (role === "STUDENT") {
      if (!ci) {
        return res.status(400).json({ error: "Debe ingresar una cédula para acceder al chat." });
      }
      const cleanCi = String(ci).replace(/\D/g, "");
      const isAuthorized = allowedStudentsList.some(
        (s) => s.ci.replace(/\D/g, "") === cleanCi
      );
      if (!isAuthorized) {
        return res.status(403).json({ error: "Acceso Denegado por Seguridad: Tu número de Cédula no está registrado/autorizado por la Profesora en el sistema." });
      }
    }

    // First, sync assignment rooms dynamically so we always have rooms for active assignments
    assignmentsList.forEach(asg => {
      const roomId = `assignment-${asg.id}`;
      if (!chatRoomsList.some(r => r.id === roomId)) {
        chatRoomsList.push({
          id: roomId,
          type: "ASSIGNMENT",
          name: `Dudas: ${asg.title}`,
          section: asg.section === "TODOS" ? undefined : asg.section,
          assignmentId: asg.id,
          createdAt: asg.createdAt
        });
      }
    });
    saveChatRooms();

    // If student, auto-ensure private room exists
    if (role === "STUDENT" && ci) {
      const cleanCi = String(ci).replace(/\D/g, "");
      const privateRoomId = `private-${cleanCi}`;
      if (!chatRoomsList.some(r => r.id === privateRoomId)) {
        chatRoomsList.push({
          id: privateRoomId,
          type: "PRIVATE",
          name: "Mensajes con Profa. Anuvis Medina",
          memberCis: [cleanCi],
          createdAt: new Date().toISOString()
        });
        saveChatRooms();
      }
    }

    if (role === "TEACHER") {
      // Teacher gets all rooms
      return res.json(chatRoomsList);
    }

    if (role === "STUDENT" && ci) {
      const cleanCi = String(ci).replace(/\D/g, "");
      const normSection = section ? String(section) : "";
      
      // Filter for student
      const studentRooms = chatRoomsList.filter(room => {
        if (room.type === "GRADE") {
          return room.section === normSection;
        }
        if (room.type === "ASSIGNMENT") {
          return !room.section || room.section === normSection;
        }
        if (room.type === "PRIVATE" || room.type === "GROUP") {
          return room.memberCis && room.memberCis.includes(cleanCi);
        }
        return false;
      });
      return res.json(studentRooms);
    }

    // Default return lists
    res.json(chatRoomsList);
  });

  // POST create a new custom group chat (Teacher-only)
  app.post("/api/chat/rooms/group", (req, res) => {
    const { name, memberCis, section } = req.body;
    if (!name || !memberCis || !Array.isArray(memberCis) || memberCis.length === 0) {
      return res.status(400).json({ error: "Nombre del grupo y lista de alumnos seleccionados son obligatorios." });
    }

    const roomId = `group-${Date.now()}`;
    const newGroup: ChatRoom = {
      id: roomId,
      type: "GROUP",
      name: name.trim(),
      section: section || undefined,
      memberCis: memberCis.map(c => String(c).replace(/\D/g, "")),
      createdAt: new Date().toISOString()
    };

    chatRoomsList.push(newGroup);
    saveChatRooms();

    // Add automatic welcome message
    const welcomeMsg: ChatMessage = {
      id: `msg-welcome-${Date.now()}`,
      roomId,
      senderName: "SISTEMA",
      senderRole: "TEACHER",
      message: `¡Grupo '${name}' creado con éxito! Miembros: ${memberCis.length} alumnos de la sección.`,
      createdAt: new Date().toISOString()
    };
    chatMessagesList.push(welcomeMsg);
    saveChatMessages();

    res.json({ success: true, room: newGroup });
  });

  // GET all chat messages (for global unread counts)
  app.get("/api/chat/messages", (req, res) => {
    const { role, ci, section } = req.query;

    if (role === "STUDENT") {
      if (!ci) {
        return res.status(400).json({ error: "Debe ingresar una cédula para acceder al chat." });
      }
      const cleanCi = String(ci).replace(/\D/g, "");
      const isAuthorized = allowedStudentsList.some(
        (s) => s.ci.replace(/\D/g, "") === cleanCi
      );
      if (!isAuthorized) {
        return res.status(403).json({ error: "Acceso Denegado por Seguridad: Tu número de Cédula no está registrado/autorizado por la Profesora en el sistema." });
      }
    }

    if (role === "TEACHER") {
      return res.json(chatMessagesList);
    }

    if (role === "STUDENT" && ci) {
      const cleanCi = String(ci).replace(/\D/g, "");
      const normSection = section ? String(section) : "";

      const studentRooms = chatRoomsList.filter(room => {
        if (room.type === "GRADE") {
          return room.section === normSection;
        }
        if (room.type === "ASSIGNMENT") {
          return !room.section || room.section === normSection;
        }
        if (room.type === "PRIVATE" || room.type === "GROUP") {
          return room.memberCis && room.memberCis.includes(cleanCi);
        }
        return false;
      });

      const studentRoomIds = studentRooms.map(r => r.id);
      const studentMessages = chatMessagesList.filter(m => studentRoomIds.includes(m.roomId));
      return res.json(studentMessages);
    }

    res.json(chatMessagesList);
  });

  // GET messages for a specific room
  app.get("/api/chat/rooms/:roomId/messages", (req, res) => {
    const { roomId } = req.params;
    const messages = chatMessagesList.filter(m => m.roomId === roomId);
    res.json(messages);
  });

  // POST send message
  app.post("/api/chat/rooms/:roomId/messages", (req, res) => {
    const { roomId } = req.params;
    const { message, senderRole, senderName, senderCi, mediaUrl, mediaType, mediaName } = req.body;

    const cleanCi = senderCi ? String(senderCi).replace(/\D/g, "") : "";

    // Check if student is registered/authorized in server database
    if (senderRole === "STUDENT") {
      if (!cleanCi) {
        return res.status(403).json({ error: "Acceso Denegado: Cédula de identidad no válida." });
      }
      const isAuthorized = allowedStudentsList.some(
        (s) => s.ci.replace(/\D/g, "") === cleanCi
      );
      if (!isAuthorized) {
        return res.status(403).json({ error: "Acceso Denegado por Seguridad: Tu número de Cédula no está registrado/autorizado por la Profesora en el sistema." });
      }
    }

    // 1. Check if student is individually restricted
    if (senderRole === "STUDENT" && cleanCi && restrictedCisList.includes(cleanCi)) {
      return res.status(403).json({ error: "La Profesora Anuvis Medina ha restringido tu participación en el chat debido al uso de vocabulario inadecuado o comportamiento inapropiado." });
    }

    // 2. Check if the chat room is muted
    if (senderRole === "STUDENT" && mutedRoomsList.includes(roomId)) {
      return res.status(403).json({ error: "Este canal de chat ha sido pausado temporalmente por la profesora Anuvis Medina. Solo lectura." });
    }

    // 3. Verify message is not empty if there is no sticker/media
    if ((!message || !message.trim()) && !mediaUrl) {
      return res.status(400).json({ error: "El mensaje o archivo no puede estar vacío." });
    }

    // 4. Checking for obscenity / offensive language
    if (senderRole === "STUDENT" && message && hasOffensiveContent(message)) {
      return res.status(400).json({
        error: "⚠️ No se permiten palabras obscenas o inapropiadas en el aula de clases. Por favor, mantén el respeto por tus compañeros y la profesora."
      });
    }

    const room = chatRoomsList.find(r => r.id === roomId);
    if (!room) {
      if (roomId.startsWith("private-")) {
        const studentCi = roomId.replace("private-", "");
        const newPrivRoom: ChatRoom = {
          id: roomId,
          type: "PRIVATE",
          name: "Mensajes Privados",
          memberCis: [studentCi],
          createdAt: new Date().toISOString()
        };
        chatRoomsList.push(newPrivRoom);
        saveChatRooms();
      } else {
        return res.status(404).json({ error: "Sala de chat no encontrada." });
      }
    }

    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}-${Math.round(Math.random() * 100000)}`,
      roomId,
      senderName: senderName || (senderRole === "TEACHER" ? "Profesora" : "Alumno General"),
      senderRole,
      senderCi: senderCi ? String(senderCi).replace(/\D/g, "") : undefined,
      message: (message || "").trim(),
      createdAt: new Date().toISOString(),
      mediaUrl,
      mediaType,
      mediaName
    };

    chatMessagesList.push(newMessage);
    saveChatMessages();

    // Optionally generate standard system notification for direct messages to teacher
    if (senderRole === "STUDENT" && room && room.type === "PRIVATE") {
      const isDuplicate = notificationsList.some(
        n => n.type === "SYSTEM" && !n.read && n.message.includes(`Mensaje de ${senderName}`)
      );
      if (!isDuplicate) {
        notificationsList.unshift({
          id: `noti-msg-${Date.now()}`,
          recipientRole: "TEACHER",
          title: "💬 Nuevo mensaje de chat",
          message: `El alumno ${senderName} te ha enviado un mensaje de chat privado.`,
          type: "SYSTEM",
          read: false,
          createdAt: new Date().toISOString()
        });
        saveNotifications();
      }
    }

    res.json({ success: true, message: newMessage });
  });

  // GET chat restrictions
  app.get("/api/chat/restrictions", (req, res) => {
    res.json({
      restrictedCis: restrictedCisList,
      mutedRooms: mutedRoomsList
    });
  });

  // POST update chat restrictions (mute students/rooms)
  app.post("/api/chat/restrictions", (req, res) => {
    const { action, ci, roomId, value } = req.body;

    if (action === "toggle-student-mute" && ci) {
      const cleanCi = String(ci).replace(/\D/g, "");
      if (value) {
        if (!restrictedCisList.includes(cleanCi)) {
          restrictedCisList.push(cleanCi);
        }
      } else {
        restrictedCisList = restrictedCisList.filter(c => c !== cleanCi);
      }
      saveRestrictions();
      return res.json({ success: true, restrictedCis: restrictedCisList });
    }

    if (action === "toggle-room-mute" && roomId) {
      if (value) {
        if (!mutedRoomsList.includes(roomId)) {
          mutedRoomsList.push(roomId);
        }
      } else {
        mutedRoomsList = mutedRoomsList.filter(id => id !== roomId);
      }
      saveRestrictions();
      return res.json({ success: true, mutedRooms: mutedRoomsList });
    }

    res.status(400).json({ error: "Parámetros de restricción no válidos." });
  });

  // DELETE assignment (Teacher removes)
  app.delete("/api/assignments/:id", (req, res) => {
    const { id } = req.params;
    const index = assignmentsList.findIndex(item => item.id === id);
    if (index === -1) {
      return res.status(404).json({ error: "Tarea no encontrada." });
    }
    assignmentsList.splice(index, 1);
    saveAssignments();
    res.json({ success: true });
  });

  // POST send reminders to students who have not yet submitted a specific assignment
  app.post("/api/assignments/:id/remind-pending", (req, res) => {
    const { id } = req.params;
    const assignment = assignmentsList.find(item => item.id === id);
    if (!assignment) {
      return res.status(404).json({ error: "Tarea no encontrada." });
    }

    // 1. Find all authorized students in this assignment's section
    // If section of assignment is 'TODOS', find all authorized students in the system
    const targetSection = assignment.section;
    const targetedStudents = allowedStudentsList.filter(
      student => targetSection === "TODOS" || student.section === targetSection
    );

    if (targetedStudents.length === 0) {
      return res.json({ success: true, count: 0, reminded: [], message: "No hay alumnos autorizados en este grado." });
    }

    // 2. Filter out students who have already submitted
    const reminded: string[] = [];
    let count = 0;

    targetedStudents.forEach(student => {
      const normStudentCi = student.ci.replace(/\D/g, "");
      
      const hasSubmitted = submissionsList.some(sub => {
        const normSubCi = sub.ci.replace(/\D/g, "");
        if (normSubCi !== normStudentCi) return false;
        
        // Match assignment ID
        if (sub.assignmentId === id) return true;
        
        // Fallback: match by title inside comments for backwards compatibility
        if (sub.comments && sub.comments.toLowerCase().includes(assignment.title.toLowerCase())) return true;
        
        return false;
      });

      if (!hasSubmitted) {
        // Send a Notification to this specific student C.I.
        const reminderNotification: AppNotification = {
          id: "reminder-notif-" + Math.random().toString(36).substring(2, 11),
          recipientRole: "STUDENT",
          recipientCi: normStudentCi,
          title: "¡Recordatorio de Tarea! ⏰",
          message: `La profesora te recuerda que tienes pendiente entregar: "${assignment.title}". Por favor, envíala pronto.`,
          type: "SYSTEM",
          read: false,
          createdAt: new Date().toISOString()
        };
        
        notificationsList.unshift(reminderNotification);
        reminded.push(student.name);
        count++;
      }
    });

    if (count > 0) {
      saveNotifications();
    }

    res.json({
      success: true,
      count,
      reminded,
      message: count > 0 
        ? `Se envió un recordatorio a ${count} estudiantes.` 
        : "Todos los alumnos de este grado ya han entregado la tarea."
    });
  });

  // POST upload media/files for assignment (PDF, Image, text, Drive url info)
  app.post("/api/upload", upload.single("file"), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: "No se subió ningún archivo." });
    }
    res.json({
      url: `/api/files/${req.file.filename}`,
      originalName: req.file.originalname,
      filename: req.file.filename,
      size: req.file.size,
      mimetype: req.file.mimetype
    });
  });

  // GET uploaded files (delivery / inline view)
  app.get("/api/files/:filename", (req, res) => {
    const { filename } = req.params;
    const filepath = path.join(process.cwd(), "uploads", filename);
    if (fs.existsSync(filepath)) {
      res.sendFile(filepath);
    } else {
      res.status(404).send("Archivo no encontrado");
    }
  });

  // GET download files (forced download with original name)
  app.get("/api/download/:filename", (req, res) => {
    const { filename } = req.params;
    const filepath = path.join(process.cwd(), "uploads", filename);
    if (fs.existsSync(filepath)) {
      const originalName = req.query.name ? String(req.query.name) : filename;
      res.download(filepath, originalName);
    } else {
      res.status(404).send("Archivo no encontrado");
    }
  });


  // GET authorized students
  app.get("/api/authorized-students", (req, res) => {
    res.json(allowedStudentsList);
  });

  // POST add/update authorized student
  app.post("/api/authorized-students", (req, res) => {
    const { name, ci, section } = req.body;
    if (!name || !ci || !section) {
      return res.status(400).json({ error: "Todos los campos son obligatorios (Nombre, Cédula, Sección)." });
    }

    if (!["Primer Grado", "Segundo Grado", "Tercer Grado", "Cuarto Grado", "Quinto Grado"].includes(section)) {
      return res.status(400).json({ error: "Grado no válido." });
    }

    const normCi = ci.toString().replace(/\D/g, "");
    // Check if duplicate in section
    const existingIndex = allowedStudentsList.findIndex(
      (s) => s.ci.replace(/\D/g, "") === normCi && s.section === section
    );

    const newStudent: AuthorizedStudent = {
      id: existingIndex !== -1 ? allowedStudentsList[existingIndex].id : Math.random().toString(36).substring(2, 11),
      name: name.trim().toUpperCase(),
      ci: ci.toString().trim(),
      section: section as any,
      createdAt: new Date().toISOString()
    };

    if (existingIndex !== -1) {
      allowedStudentsList[existingIndex] = newStudent;
    } else {
      allowedStudentsList.unshift(newStudent);
    }

    saveAllowedStudents();
    res.status(201).json({ success: true, student: newStudent });
  });

  // POST bulk/import authorized students for a section
  app.post("/api/authorized-students/import", (req, res) => {
    const { section, studentsText } = req.body;
    if (!section || !studentsText) {
      return res.status(400).json({ error: "Sección y texto de alumnos obligatorios." });
    }

    if (!["Primer Grado", "Segundo Grado", "Tercer Grado", "Cuarto Grado", "Quinto Grado"].includes(section)) {
      return res.status(400).json({ error: "Grado no válido." });
    }

    const lines = studentsText.split("\n").map((l: string) => l.trim()).filter(Boolean);
    const addedStudents: AuthorizedStudent[] = [];

    lines.forEach((line: string) => {
      let parts = line.split(/[,;\t]/).map((p: string) => p.trim()).filter(Boolean);
      
      if (parts.length < 2) {
        const words = line.split(/\s+/);
        if (words.length >= 2) {
          const ciIndex = words.findIndex((w: string) => /^\d+$/.test(w.replace(/\D/g, "")));
          if (ciIndex !== -1) {
            const rawCi = words[ciIndex];
            const nameWords = words.filter((_, idx) => idx !== ciIndex);
            parts = [rawCi, nameWords.join(" ")];
          }
        }
      }

      if (parts.length >= 2) {
        let rawCi = parts[0];
        let rawName = parts[1];

        if (/^\d+$/.test(rawName.replace(/\D/g, "")) && !/^\d+$/.test(rawCi.replace(/\D/g, ""))) {
          rawCi = parts[1];
          rawName = parts[0];
        }

        const cleanCi = rawCi.trim();
        const cleanName = rawName.replace(/["']/g, "").trim().toUpperCase();

        if (cleanCi && cleanName) {
          const normCi = cleanCi.replace(/\D/g, "");
          const existingIndex = allowedStudentsList.findIndex(
            (s) => s.ci.replace(/\D/g, "") === normCi && s.section === section
          );

          const studentObj: AuthorizedStudent = {
            id: existingIndex !== -1 ? allowedStudentsList[existingIndex].id : Math.random().toString(36).substring(2, 11),
            name: cleanName,
            ci: cleanCi,
             section: section as any,
            createdAt: new Date().toISOString()
          };

          if (existingIndex !== -1) {
            allowedStudentsList[existingIndex] = studentObj;
          } else {
            allowedStudentsList.push(studentObj);
          }
          addedStudents.push(studentObj);
        }
      }
    });

    saveAllowedStudents();
    res.json({ success: true, count: addedStudents.length, students: addedStudents });
  });

  // DELETE authorized student
  app.delete("/api/authorized-students/:id", (req, res) => {
    const { id } = req.params;
    const index = allowedStudentsList.findIndex((s) => s.id === id);

    if (index === -1) {
      return res.status(404).json({ error: "Alumno no encontrado." });
    }

    allowedStudentsList.splice(index, 1);
    saveAllowedStudents();

    res.json({ success: true });
  });


  // Hotfix static route for assets during production or vite delivery
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
